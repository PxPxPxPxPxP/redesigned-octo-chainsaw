return {
    descriptions = {
        Joker = {
            j_xiferp_corrupted_dna = {
                name = 'Corrupted DNA',
                text = {
                    'Incorrectly copies the first scored card of a hand.',
                },
                
         },
            j_xiferp_top_to_bottom = {
                name = 'Top To Bottom',
                text = {
                    'Lets straights go over the Ace.',
                    '(example: Q, K, A, 2, 3)',
                },
                
         },
            j_xiferp_astro_card = {
                name = 'Out In Spades...',
                text = {
                    'At the end of a round, randomly turns one',
                    'card held in hand to a spade.',
                },
                
         },
      
        },
    },
}