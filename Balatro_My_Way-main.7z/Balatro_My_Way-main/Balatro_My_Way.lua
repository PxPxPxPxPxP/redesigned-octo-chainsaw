assert(SMODS.load_file("src/Jokercode.lua"))()
assert(SMODS.load_file("src/Challengecode.lua"))()
assert(SMODS.load_file("src/config.lua"))()